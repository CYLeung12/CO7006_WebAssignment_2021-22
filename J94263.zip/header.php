<header>
    <div id="top-header" class="container">
        <a href="index.php"><img id="logo" src="image/logo.png" alt="Taste the World is a website sharing recipes of the world dishes">
        </a>
        <a href="form.php" class="submitReceipe">Submit Your Recipe</a>
    </div>
    <nav>
        <ul class="conrainer">
            <li><a href="index.php">Home</a></li>
            <li><a href="inspiration.php">Inspiration</a></li>
            <li><a href="blog.php">Cooking Tips</a></li>
            <li><a href="contact.php">Contact us</a></li>
        </ul>
    </nav>
</header>